package com.springmvc.controller;

import com.springmvc.entity.Employee;
import com.springmvc.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/employee/")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("signup")
    public String showSignUpForm(@ModelAttribute("employee") Employee employee) {
        return "add-employee";
    }

    @GetMapping("list")
    public String showUpdateForm(Model model) {
        model.addAttribute("employee", employeeRepository.findAll());
        return "index";
    }

    @PostMapping("add")
    public String addStudent(@ModelAttribute("employee") Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-employee";
        }
        employee.setStatus("probation");
        employeeRepository.save(employee);
        return "redirect:list";
    }

    @GetMapping("edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid student Id:" + id));
        model.addAttribute("employee", employee);
        return "update-employee";
    }

    @PostMapping("update/{id}")
    public String updateStudent(@PathVariable("id") long id,@ModelAttribute("employee") Employee employee, BindingResult result,
                                Model model) {
        if (result.hasErrors()) {
            employee.setEmployeeId(id);
            return "update-employee";
        }

        employeeRepository.save(employee);
        model.addAttribute("employee", employeeRepository.findAll());
        return "index";
    }

    @GetMapping("delete/{id}")
    public String deleteStudent(@PathVariable("id") long id, Model model) {
        Employee student = employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid student Id:" + id));
        employeeRepository.delete(student);
        model.addAttribute("employee", employeeRepository.findAll());
        return "index";
    }
}
