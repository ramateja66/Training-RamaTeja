package com.springmvc.entity;

import javax.persistence.*;


@Table(name = "employee")
@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long employeeId;
    @Column
    private String employeeName;
    @Column
    private String employeeAddress;
    @Column
    private Long phoneNumber;
    @Column
    private String martialStatus;

    @Column
    private String status;

    public Long getEmployeeId() {
        return employeeId;
    }

    public Employee() {

    }

    public Employee(Long employeeId, String employeeName, String employeeAddress, Long phoneNumber, String martialStatus, String status) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeAddress = employeeAddress;
        this.phoneNumber = phoneNumber;
        this.martialStatus = martialStatus;
        this.status = status;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeAddress() {
        return employeeAddress;
    }

    public void setEmployeeAddress(String employeeAddress) {
        this.employeeAddress = employeeAddress;
    }

    public Long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMartialStatus() {
        return martialStatus;
    }

    public void setMartialStatus(String martialStatus) {
        this.martialStatus = martialStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
