package com.employee.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "employee")
@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long employeeId;
    @Column
    private String employeeName;
    @Column
    private String employeeAddress;
    @Column
    private Long phoneNumber;
    @Column
    private String martialStatus;
    @Column
    private String status;
}
