package com.employee.controller;

import com.employee.dto.EmployeeDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.employee.service.EmployeeService;

@RestController
@RequestMapping(value="/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping(value="/")
    public ResponseEntity createEmployee(@RequestBody EmployeeDto employee) {
        return employeeService.createEmployee(employee);
    }

    @GetMapping(value="/{id}")
    public ResponseEntity getEmployee(@PathVariable(value = "id") Long id) {
        return employeeService.getEmployee(id);
    }

    @PostMapping(value= "/{id}")
    public ResponseEntity updateEmployee(@PathVariable(value = "id") Long id ) {
        return employeeService.updateEmployee(id);
    }


    @GetMapping(value= "/")
    public ResponseEntity listEmployee() {
        return employeeService.listAllEmployees();
    }

    

}
