package com.employee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeDto {

    private String employeeName;
    private String employeeAddress;
    private Long phoneNumber;
    private String martialStatus;
    private String status;
}
