package com.employee.dto.response;

import lombok.Data;

@Data
public class EmployeeResponseDto {
    private Long employeeId;
    private String employeeName;
    private String employeeAddress;
    private Long phoneNumber;
    private String martialStatus;
    private String status;
}
