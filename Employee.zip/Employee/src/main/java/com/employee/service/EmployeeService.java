package com.employee.service;

import com.employee.dto.EmployeeDto;
import com.employee.dto.common.ResponseDto;
import com.employee.dto.response.EmployeeResponseDto;
import com.employee.entity.Employee;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.employee.repository.EmployeeRepository;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public ResponseEntity createEmployee(EmployeeDto employeeDto) {
        ResponseDto<EmployeeResponseDto> employeeResponseDto = new ResponseDto<>();
        ModelMapper modelMapper = new ModelMapper();
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        Employee emp = employeeRepository.save(employee);
        if (emp != null) {
            EmployeeResponseDto employeeDto1 = modelMapper.map(emp, EmployeeResponseDto.class);
            employeeResponseDto.setData(employeeDto1);
            employeeResponseDto.setStatus("200Ok");
            employeeResponseDto.setMessage("Employee Created");
            ResponseEntity.ok().body(employeeResponseDto);
        } else {
            employeeResponseDto.setData(null);
            employeeResponseDto.setError("500");
            employeeResponseDto.setMessage("Employee Creation Failed");
        }
        return ResponseEntity.ok().body(employeeResponseDto);
    }

    public ResponseEntity getEmployee(Long id) {
        ResponseDto<EmployeeResponseDto> employeeResponseDto = new ResponseDto<>();
        ModelMapper modelMapper = new ModelMapper();
        Employee employee = employeeRepository.findById(id).get();
        if (employee == null) {
            employeeResponseDto.setData(null);
            employeeResponseDto.setError("500");
            employeeResponseDto.setMessage("Employee Creation Failed");
        } else {
            EmployeeResponseDto employeeDto1 = modelMapper.map(employee, EmployeeResponseDto.class);
            employeeResponseDto.setData(employeeDto1);
            employeeResponseDto.setMessage("Employee Fetched");
            employee.setStatus("200Ok");
        }
        return ResponseEntity.ok().body(employeeResponseDto);
    }

    public ResponseEntity updateEmployee(Long id) {
        ModelMapper modelMapper = new ModelMapper();
        ResponseDto<EmployeeResponseDto> employeeResponseDto = new ResponseDto<>();
        Employee employee = employeeRepository.findById(id).get();
        if (employee == null) {
            employeeResponseDto.setData(null);
            employeeResponseDto.setError("500");
            employeeResponseDto.setMessage("Employee Creation Failed");
        }
        employee.setStatus("Regular");
        Employee updatedEmployee = employeeRepository.save(employee);
        EmployeeResponseDto responseDto = modelMapper.map(employee, EmployeeResponseDto.class);
        employeeResponseDto.setData(responseDto);
        employeeResponseDto.setMessage("Updated Successfully");
        employeeResponseDto.setStatus("200Ok");
        return ResponseEntity.ok().body(employeeResponseDto);
    }

    public ResponseEntity listAllEmployees( ){
        ModelMapper modelMapper = new ModelMapper();
       List<Employee> employeeList = employeeRepository.findAll();
      List<EmployeeResponseDto> employeeResponseDtos = modelMapper.map(employeeList,List.class);
        ResponseDto<List<EmployeeResponseDto>> employeeResponseDto = new ResponseDto<>();
        employeeResponseDto.setData(employeeResponseDtos);
        employeeResponseDto.setStatus("200OK");
        return  ResponseEntity.ok().body(employeeResponseDtos);
    }
}
