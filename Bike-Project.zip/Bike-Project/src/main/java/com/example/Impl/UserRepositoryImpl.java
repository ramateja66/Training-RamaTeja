package com.example.Impl;

import com.example.dao.User;
import com.example.repository.UserRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Service
public class UserRepositoryImpl implements UserRepository {


    @Autowired
    private SessionFactory sessionFactory;


    @Override
    @Transactional
    public void saveBike(User user) {
        Session session=sessionFactory.getCurrentSession();
        session.save(user);

    }

    @Override
    public void updateBike(User user, int id) {

    }

    @Override
    public void deleteBike(int id) {

    }

    @Override
    public List<User> getAllBike() {
        return null;
    }

    @Override
    @Transactional
    public User getUserById(int id) {
        Session session=sessionFactory.getCurrentSession();
           Query q= session.createQuery("from User u where u.id=:x");
            q.setParameter("x",id);
            User user= (User) q.getResultList().get(0);
            return user;
    }
}
