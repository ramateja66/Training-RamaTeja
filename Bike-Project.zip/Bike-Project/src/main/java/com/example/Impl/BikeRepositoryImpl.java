package com.example.Impl;

import com.example.dao.Bike;
import com.example.repository.BikeRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;

@Service
public class BikeRepositoryImpl implements BikeRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Transactional
    public void saveBike(Bike bike) {
        Session session=sessionFactory.getCurrentSession();
        session.save(bike);
    }

    @Override
    public void updateBike(Bike bike) {

    }

    @Override
    public void deleteBike(int id) {


    }

    @Override
    public List<Bike> getAllBike() {
        Session session=sessionFactory.getCurrentSession();
        List<Bike> al=session.createQuery("from Bike",Bike.class).list();
        return al;
    }
}
