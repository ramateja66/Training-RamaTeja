package com.example.controllers;

import com.example.Impl.UserRepositoryImpl;
import com.example.dao.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {

    @Autowired
    private UserRepositoryImpl userRepository;

    @RequestMapping(value="/user")
    public String newUser(Model model){

        model.addAttribute("user",new User());
        return "userregister";
    }

    @PostMapping(value="/newuser")
    public String saveUser(User user,Model model){
        model.addAttribute("id",user.getId());
        userRepository.saveBike(user);
        return "home";
    }

}
