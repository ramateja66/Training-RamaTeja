package com.example.controllers;

import com.example.Impl.BikeRepositoryImpl;
import com.example.Impl.UserRepositoryImpl;
import com.example.dao.Bike;
import com.example.dao.User;
import com.example.repository.BikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class BikeController {

    @Autowired
    private BikeRepositoryImpl bikeRepository;

    @Autowired
   private UserRepositoryImpl userRepository;

    @RequestMapping(value="/")
    public String home(Model model)
    {
        model.addAttribute("user",new User());
        return "/userregister";
    }

    @RequestMapping(value="/allbike",method= RequestMethod.GET)
    public String allBike(Model model){
        List<Bike> al=bikeRepository.getAllBike();
        model.addAttribute("allBike",al);
        return "bikes";
    }

    @RequestMapping(value="/new/{id}")
    public String newBike(@PathVariable int id,Model model)
    {
        model.addAttribute("id",id);
        model.addAttribute("bike",new Bike());
        return "newbike";
    }

    @RequestMapping(value="/newBike/{id}",method=RequestMethod.POST)
    public String newBike(Bike bike,@PathVariable int id)
    {
        bike.setUser_id(userRepository.getUserById(id));
      bikeRepository.saveBike(bike);
        return "redirect:/home";
    }
}
