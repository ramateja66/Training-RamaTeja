package com.example.repository;

import com.example.dao.Bike;
import com.example.dao.User;

import java.util.List;

public interface UserRepository {

    public void saveBike(User user);

    public void updateBike(User user, int id);

    public void deleteBike(int id);

    public List<User> getAllBike();

    public User getUserById(int id);
}
