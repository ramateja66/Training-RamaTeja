package com.example.repository;

import com.example.dao.Bike;

import java.util.List;

public interface BikeRepository {

    public void saveBike(Bike bike);

    public void updateBike(Bike bike);

    public void deleteBike(int id);

    public List<Bike> getAllBike();


}
