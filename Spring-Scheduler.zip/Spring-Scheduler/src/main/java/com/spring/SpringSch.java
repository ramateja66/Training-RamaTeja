package com.spring;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.spring.impl.StudentImp;

@Configuration
@EnableScheduling
public class SpringSch {
	
	@PostConstruct
    public void onStartup() {
		sched();
    }
	
	@Autowired
	private StudentImp studentimp;
	
	@Scheduled(cron = "*/12000 * * * * *")
	public void sched() {
		studentimp.stat();
		System.out.println("Updated");
	}

}
