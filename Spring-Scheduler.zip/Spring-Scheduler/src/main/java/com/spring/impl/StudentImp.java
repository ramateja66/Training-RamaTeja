package com.spring.impl;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.spring.pojo.Student;
import com.spring.repo.StudentImpl;
@Service
public class StudentImp  {
	
	@Autowired
	private StudentImpl studentImpl;

	@Transactional
	public void save(Student student) {
		// TODO Auto-generated method stub
		studentImpl.save(student);
		//return null;
	}
	
	@Transactional
	public void stat() {
		studentImpl.statusUpdater();
	}

	
	

}
