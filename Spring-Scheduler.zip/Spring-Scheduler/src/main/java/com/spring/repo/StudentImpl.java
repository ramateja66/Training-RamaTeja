package com.spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.pojo.Student;

@Repository
public interface StudentImpl extends CrudRepository<Student,Integer> {
	
	@Query("update Student a set a.status='old' where a.status='new'")
    @Modifying
    public void statusUpdater();

}
