package com.restapi.service;

import com.restapi.model.Patient;
import com.restapi.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public void save(Patient patient){
        patientRepository.save(patient);

    }
}
