package com.restapi.service;

import com.restapi.model.Doctor;
import com.restapi.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public void save(Doctor doctor){
        doctorRepository.save(doctor);
    }

    public Doctor getDoctor(int id){
        return doctorRepository.getById(id);
    }

}
