package com.restapi.service;

import com.restapi.model.Appointment;
import com.restapi.model.Doctor;
import com.restapi.model.Patient;
import com.restapi.repository.AppointmentRepository;
import com.restapi.repository.DoctorRepository;
import com.restapi.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@EnableTransactionManagement
public class AppointmentService {

    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private AppointmentRepository appointmentRepository;
    @Autowired
    private DoctorRepository doctorRepository;

    public void saveAppointment(Appointment appointment, int id){
        Patient pat=patientRepository.getById(id);
        appointment.setPid(pat);
        appointmentRepository.save(appointment);
    }

   public List<Appointment> display(String specType){
        List<Appointment> apptment=new ArrayList<Appointment>();
        apptment=appointmentRepository.display(specType);
        return apptment;
    }

    public void deleteAppointment(int id){
        appointmentRepository.deleteById(id);
    }
    @Transactional
    public void acceptAppointment(int id){
        appointmentRepository.accept(id);
    }

    @Transactional
    public void rejectAppointment(int id){
        appointmentRepository.reject(id);
    }

}
