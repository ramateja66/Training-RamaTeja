package com.restapi.controller;

import com.restapi.model.Appointment;
import com.restapi.model.Doctor;
import com.restapi.model.Patient;
import com.restapi.repository.DoctorRepository;
import com.restapi.repository.PatientRepository;
import com.restapi.service.AppointmentService;
import com.restapi.service.DoctorService;
import com.restapi.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class HomeController {

    @Autowired
    private PatientService patientService;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/")
    public String home(){
        return  "home";
    }

    @PostMapping("/savePatient")
    public String savePatient(@RequestBody Patient patient)
    {
        patientService.save(patient);
        return "Success";
    }

    @PostMapping("/saveDoctor")
    public String saveDoctor(@RequestBody Doctor doctor)
    {
        doctorService.save(doctor);
        return "Success";
    }

    @PostMapping("appointment/{id}/save")
    public String saveAppointment(@PathVariable int id, @RequestBody Appointment appointment){
        appointmentService.saveAppointment(appointment,id);
        return "Appointment Booked";
    }

    @GetMapping("/doctor/{id}/showAppointments")
    public List<Appointment> showAppointment(@PathVariable int id)
    {
        Doctor doctor=doctorService.getDoctor(id);
        return appointmentService.display(doctor.getSpeciality());
    }

    @DeleteMapping("/patient/{id}/delete")
    public void delete(@PathVariable int id){
        appointmentService.deleteAppointment(id);
    }

    @PutMapping("/doctor/{id}/accept")
    public void acceptAppointment(@PathVariable int id){
        appointmentService.acceptAppointment(id);
    }

    @PutMapping("/doctor/{id}/reject")
    public void rejectAppointment(@PathVariable int id){
        appointmentService.rejectAppointment(id);
    }

}
