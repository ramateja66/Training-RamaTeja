package com.restapi.repository;

import com.restapi.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment,Integer> {

    @Query("Select a from Appointment a where a.specType=:specType")
    public List<Appointment> display(@Param("specType") String specType);

    @Query("update Appointment a set a.status='accepted' where a.aid=:aid")
    @Modifying
    public void accept(@Param("aid") int aid);

    @Query("update Appointment a set a.status='rejected' where a.aid=:aid")
    @Modifying
    public void reject(@Param("aid") int aid);
}
