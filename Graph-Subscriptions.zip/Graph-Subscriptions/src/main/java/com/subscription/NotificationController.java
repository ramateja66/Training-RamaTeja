package com.subscription;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.*;
import com.microsoft.graph.models.ChangeNotification;
import com.microsoft.graph.models.ChangeNotificationCollection;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.requests.MessageCollectionPage;
import com.microsoft.graph.serializer.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import com.microsoft.graph.serializer.DefaultSerializer;
import com.microsoft.graph.serializer.ISerializer;
import com.microsoft.graph.logger.DefaultLogger;

@Controller
public class NotificationController {
	
	@Autowired
	private SendSubscription sendSubscription;
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/api", headers = { "content-type=text/plain" })
	public ResponseEntity getItem(@RequestParam("validationToken") String validationToken) {
		System.out.println(validationToken);
		return new ResponseEntity(validationToken, HttpStatus.OK);

	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/api")
	public CompletableFuture<ResponseEntity<String>> getNotification(@RequestBody final String jsonPayload) {
		 JSONObject jsonObj = new JSONObject(jsonPayload);
		 System.out.println(jsonObj);
		ISerializer ss = new DefaultSerializer(new DefaultLogger());
		ChangeNotificationCollection changeNotificationCollection = ss.deserializeObject(jsonPayload,
				ChangeNotificationCollection.class);
		for (ChangeNotification changeNotification : changeNotificationCollection.value) {
			System.out.println(changeNotification.resource);
		}
		MessageCollectionPage mcp=sendSubscription.processInbox();
		List<Message> li=mcp.getCurrentPage();
		System.out.println(li.get(0).subject);
		return CompletableFuture.completedFuture(ResponseEntity.accepted().body(""));
	}

}
