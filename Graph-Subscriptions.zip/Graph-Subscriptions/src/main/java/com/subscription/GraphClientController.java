package com.subscription;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.azure.identity.UsernamePasswordCredential;
import com.azure.identity.UsernamePasswordCredentialBuilder;
import com.microsoft.graph.authentication.*;

@Service
public class GraphClientController {
	
	public final static String APP_ID = "0813e453-bd58-4383-9773-9c2be252c130";
//	public final static String USER_NAME = "goodadmin@goodtech.onmicrosoft.com";
//	public final static String PASS_WORD = "G00dEx365";
    public final static List<String> scopes = Arrays.asList("https://graph.microsoft.com/.default");

		
	public static TokenCredentialAuthProvider getCredentialsBasedAuth(String USER_NAME,String PASS_WORD) {
		 UsernamePasswordCredential usernamePasswordCredential = new UsernamePasswordCredentialBuilder().clientId(APP_ID)
				.username(USER_NAME).password(PASS_WORD).build();
		return new TokenCredentialAuthProvider(scopes, usernamePasswordCredential);
	}

}
