package com.subscription;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.microsoft.graph.models.MailFolder;
import com.microsoft.graph.models.Subscription;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.requests.MailFolderCollectionPage;
import com.microsoft.graph.requests.MessageCollectionPage;
import com.microsoft.graph.serializer.OffsetDateTimeSerializer;

@Controller
public class SendSubscription {
	
	GraphServiceClient graphClient;
	@Autowired
	private GraphClientController graphClientController;
	
/*	@RequestMapping(value="/",method=RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("user",new User());
		return "home";
	}*/
	
	//@RequestMapping(value="/send",method=RequestMethod.POST)
	public String send(String userName,String password) throws ParseException
	{
	
	graphClient = GraphServiceClient.builder()
			.authenticationProvider(graphClientController.getCredentialsBasedAuth(userName,password)).buildClient();
	Subscription subscription = new Subscription();
	subscription.changeType = "created,updated";
	subscription.notificationUrl = "https://2616-2405-201-c036-28d8-e596-2176-9d9c-8419.ngrok.io/api";
	subscription.resource = "/me/mailfolders('inbox')/messages";
	subscription.expirationDateTime = OffsetDateTimeSerializer.deserialize("2022-02-26T18:23:45.9356913Z");
	subscription.clientState = "secretClientValue";
	subscription.latestSupportedTlsVersion = "v1_2";
	Subscription newSubscription = graphClient.subscriptions().buildRequest().post(subscription);

	System.out.println("sub id : " + newSubscription.id);
	
	return "success" ;
	}
	
	public MessageCollectionPage processInbox() {
		
		String folderId = null;
		MailFolderCollectionPage mailFolders = graphClient.me().mailFolders()
				.buildRequest()
				.get();
		List<MailFolder> mail=mailFolders.getCurrentPage();
		for(MailFolder mf:mail)
		{
			if(mf.displayName.equalsIgnoreCase("Junk Email"))
			{
				folderId= mf.id;
			}
		}
			
		MessageCollectionPage messages = graphClient.me().mailFolders(folderId).messages()
		    .buildRequest()
		    .get();
		System.out.println(messages.getCurrentPage());
		return messages;
	}
}
