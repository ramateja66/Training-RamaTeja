package com.subscription;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphSubscriptionsApplication implements CommandLineRunner {

	@Autowired
	SendSubscription sendSubscription;
	public static void main(String[] args) {
		SpringApplication.run(GraphSubscriptionsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Map<String ,String > map=new HashMap<String,String>();
		map.put("goodadmin@goodtech.onmicrosoft.com", "G00dEx365");
		map.put("g3tech1@goodtech.onmicrosoft.com","G3tester03");
	//	map.put("g3tech2@goodtech.onmicrosoft.com", "G3tester04");
		
		 for (Map.Entry<String,String> entry : map.entrySet()) {
			 sendSubscription.send(entry.getKey(), entry.getValue());
			 }
		
	}

}
