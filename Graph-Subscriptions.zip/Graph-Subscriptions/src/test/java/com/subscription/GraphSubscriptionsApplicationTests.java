package com.subscription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphSubscriptionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
